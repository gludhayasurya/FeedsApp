-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 29, 2024 at 07:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spritle`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `entry_id` bigint(20) UNSIGNED NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `parent_id`, `user_id`, `entry_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 1, 'bye', '2024-07-27 23:57:36', '2024-07-27 23:57:36'),
(2, NULL, 1, 1, 'byr', '2024-07-28 03:03:13', '2024-07-28 03:03:13'),
(3, NULL, 1, 1, 'hey', '2024-07-28 08:46:55', '2024-07-28 08:46:55'),
(4, NULL, 1, 1, 'checki', '2024-07-28 08:47:03', '2024-07-28 08:47:03'),
(5, NULL, 1, 1, 'done', '2024-07-28 08:51:52', '2024-07-28 08:51:52'),
(6, NULL, 1, 1, 'overrr', '2024-07-28 08:59:48', '2024-07-28 08:59:48'),
(7, NULL, 1, 2, 'jii', '2024-07-28 09:06:09', '2024-07-28 09:06:09'),
(8, NULL, 1, 2, 'kk', '2024-07-28 09:06:18', '2024-07-28 09:06:18'),
(9, NULL, 1, 5, 'yayyy', '2024-07-28 09:16:29', '2024-07-28 09:16:29'),
(10, NULL, 1, 5, 'ji', '2024-07-28 20:06:44', '2024-07-28 20:06:44'),
(11, NULL, 1, 5, 'koko', '2024-07-28 20:56:31', '2024-07-28 20:56:31'),
(12, NULL, 1, 5, 'llll', '2024-07-28 20:57:11', '2024-07-28 20:57:11'),
(13, NULL, 1, 5, 'ooo', '2024-07-28 20:58:35', '2024-07-28 20:58:35'),
(14, NULL, 5, 9, 'ko', '2024-07-28 23:20:25', '2024-07-28 23:20:25'),
(15, NULL, 5, 7, 'llll', '2024-07-28 23:21:07', '2024-07-28 23:21:07');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_likes`
--

INSERT INTO `comment_likes` (`id`, `comment_id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 11, 1, '2024-07-28 22:58:21', '2024-07-28 22:58:21'),
(7, 13, 5, '2024-07-28 23:21:24', '2024-07-28 23:21:24');

-- --------------------------------------------------------

--
-- Table structure for table `entries`
--

CREATE TABLE `entries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `entries`
--

INSERT INTO `entries` (`id`, `user_id`, `content`, `created_at`, `updated_at`) VALUES
(1, 1, 'hi', '2024-07-27 22:37:12', '2024-07-27 22:37:12'),
(2, 1, 'how are you', '2024-07-28 03:02:49', '2024-07-28 03:02:49'),
(3, 2, 'hey, I went Boating today.', '2024-07-28 06:16:18', '2024-07-28 06:16:18'),
(4, 1, 'oops', '2024-07-28 08:59:14', '2024-07-28 08:59:14'),
(5, 1, 'may day', '2024-07-28 09:06:58', '2024-07-28 09:06:58'),
(6, 5, 'hurray!!!!', '2024-07-28 23:04:56', '2024-07-28 23:04:56'),
(7, 5, 'Oyee', '2024-07-28 23:07:41', '2024-07-28 23:07:41'),
(8, 5, 'goddd', '2024-07-28 23:08:29', '2024-07-28 23:08:29'),
(9, 5, 'kk', '2024-07-28 23:12:43', '2024-07-28 23:12:43');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `entry_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `user_id`, `entry_id`, `created_at`, `updated_at`) VALUES
(3, 11, 3, '2024-07-28 07:33:13', '2024-07-28 07:33:13'),
(7, 1, 3, '2024-07-28 07:38:45', '2024-07-28 07:38:45'),
(15, 1, 1, '2024-07-28 21:14:35', '2024-07-28 21:14:35'),
(18, 1, 4, '2024-07-28 22:36:02', '2024-07-28 22:36:02'),
(21, 5, 7, '2024-07-28 23:07:48', '2024-07-28 23:07:48'),
(22, 5, 9, '2024-07-28 23:12:49', '2024-07-28 23:12:49');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_07_27_133630_create_entries_table', 2),
(6, '2024_07_27_133631_create_likes_table', 2),
(7, '2024_07_27_133632_create_comments_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'UdhayakumarG', 'gludhayasurya@gmail.com', NULL, '$2y$12$v4Xsj/3jPCXKzdanexMDg.2G/8I959ZnEwDQ8SBz.EuP1S.jTXHdu', 'HFd5Z6OXPJMZctaR26aN1Xk6a5Sa2bK7cH0nx1Zdhww8HQGVJPLy1NhOQry5', '2024-07-27 07:43:50', '2024-07-27 07:44:27'),
(2, 'SuryaPrakash', 'surya@gmail.com', NULL, '$2y$12$QORdX/oGrDCfGIOyp40WQ.Ik5BrCxXcOzb.uli82ltSwrxZWyO6wG', NULL, '2024-07-28 06:02:36', '2024-07-28 06:02:36'),
(3, 'Mohandoss', 'mohan@gmail.com', NULL, '$2y$12$RDYNBIU6SXvwx0a5b1whZuLQE5pz.nUUwu2b49SmNaMRZ2rld0.46', NULL, '2024-07-28 06:53:02', '2024-07-28 06:53:02'),
(4, 'Guna', 'guna@gmail.com', NULL, '$2y$12$vfgNIaUlwZzddDgNpqTbiuvKdKX6XCsZpkpgDGqDEeqfgBk8l4I0y', NULL, '2024-07-28 07:06:16', '2024-07-28 07:06:16'),
(5, 'Alex', 'alex@gmail.com', NULL, '$2y$12$VEI3G3EPDOPCKMv1STz/8OstcbcO/z5ttcyjVNymkM5T0Y5pxNqI6', NULL, '2024-07-28 07:13:26', '2024-07-28 07:13:26'),
(6, 'John', 'john@gmail.com', NULL, '$2y$12$3gA6EpwJMZeCC4cauMaQ1u4kTTGojHDmjc9w1pYq4oboKsjMC5TAq', NULL, '2024-07-28 07:17:36', '2024-07-28 07:17:36'),
(7, 'David', 'david@gmail.com', NULL, '$2y$12$Vep/EwRqF.4po1Fp1XWkGOi4BeUL0tG.jRh2HuNdDGYYunV7LsVAa', NULL, '2024-07-28 07:18:40', '2024-07-28 07:18:40'),
(8, 'Vijay', 'vijay@gmail.com', NULL, '$2y$12$MIofPlR6YWrOpiF0exi1eOnpeheJ0t6c931O4sm92A2MenMh16fNG', NULL, '2024-07-28 07:21:32', '2024-07-28 07:21:32'),
(9, 'Ram', 'ram@gmail.com', NULL, '$2y$12$yQrvy8fQgGuX0dtYqjAESeXU7urDRUBh2MGfnI4BOepzvKG9Ow5CW', NULL, '2024-07-28 07:27:08', '2024-07-28 07:27:08'),
(10, 'Jessica', 'jessy@gmail.com', NULL, '$2y$12$j63WFdAp.CLCbfZutKDmiOKBjDRcM.Ho91GdIwk9Z3pvclDcf3SG6', NULL, '2024-07-28 07:30:11', '2024-07-28 07:30:11'),
(11, 'Riyaz', 'riyaz@gmail.com', NULL, '$2y$12$laNWndqsJ5ByFVb4bKTWVukNAQaEqBcNscnZk19rwPbvGWRo3CqmW', NULL, '2024-07-28 07:32:35', '2024-07-28 07:32:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_entry_id_foreign` (`entry_id`),
  ADD KEY `id` (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entries`
--
ALTER TABLE `entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entries_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `likes_user_id_foreign` (`user_id`),
  ADD KEY `likes_entry_id_foreign` (`entry_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `entries`
--
ALTER TABLE `entries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_entry_id_foreign` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `entries`
--
ALTER TABLE `entries`
  ADD CONSTRAINT `entries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_entry_id_foreign` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
